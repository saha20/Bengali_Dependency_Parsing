
--Juhi Tandon--

Head computation is the task of computing the heads of noun and verb  groups and more importantly they provide sufficient information 
for further processing of the sentence according to the Paninian Theory.

Dependency - SSFAPI

Usage - python head_computation.py input_filename
Output will be stored in input_filename.head


