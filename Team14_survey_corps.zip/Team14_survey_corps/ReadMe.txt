Code location:
	src/code --> python(.py) files
	src/notebooks -- > ipynb files
	src/Head_Computation --> Head Computation module

Saved model checkpoints : https://iiitaphyd-my.sharepoint.com/:f:/g/personal/shubhankar_saha_students_iiit_ac_in/EuPJzzZ0fm5PlVkZejX6I-0BLoWz8StoLvZDEqB26oESww?e=6aGz5R

Data location:
	data/raw_bengali_data.zip --> ssf format bengali treebank 
	data/head_data.zip --> data used for experiments and this project

GitHub repo :	https://github.com/saha20/Bengali_Dependency_Parsing 

Project Report: doc/report.pdf

Instructions to run the code is given at the beginning of the py files.